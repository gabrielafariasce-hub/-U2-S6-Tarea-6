package com.example.u2_s6_taller6

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
